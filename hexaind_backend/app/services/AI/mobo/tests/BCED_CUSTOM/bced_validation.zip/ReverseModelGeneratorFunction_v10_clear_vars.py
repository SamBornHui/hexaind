# -*- coding: utf-8 -*-
"""
Created on Fri Apr 28 15:16:42 2023

@author: weiserm
"""
import math 
import numpy as np
import random
import pandas as pd
import matplotlib.pyplot as plt
from csv import DictWriter
import os

#Class definition
class CCommon:
   BlankElementSize=0.2
   ElementSize = 1.0
   ContainerPID = 100
   NumParts = 0
   maxShellDivHoop=0
   
class CResults:
    Fail=0
    ArcLength=0
    SurfaceArea=0
    Mass=0
    Volume=0
    MinRadius=0
    Roughness=0
    buckle_time=0
    buckle_pressure=0
    
class CData:
   Dimensions = 0
   ElementsThroThickness = 5
   OuterPressureDuringDraw = 0.1 # (Bar)
   FrictionToolBlank = 0.04
   Damping = 0.3
   BlankConstrainedRad = 0.0
   NumQuarters = 2
   Airbag_height=0
   AirbagVolume=0
   CreateBlank = False
   Tools3D_File = "xxxTools.k"
   Blank3D_File = "Blank.k"
   FormingDataFile = "FormingData.txt"
   PerformanceDataFile = "Performance.txt"
   ArcLength = []
   
class ToolsNode2DType:
   def __init__(self, x=0, y=0, PID=0, ElementThickness=0):
      self.x = x
      self.y = y
      self.PID = PID
      self.DivHoop = 0
      self.ElementThickness = ElementThickness

class NodeType3D:
   def __init__(self, ID=0, x=0, y=0, z=0, PID=0, ElementThickness=0):
      self.ID = ID
      self.PID = PID
      self.x = x
      self.y = y
      self.z = z
      self.OnSurface = 0
      self.Included = True
      self.AtEdge = False
      self.Tc = 0
      self.Rc = 0
      self.ElementThickness = ElementThickness
      
class ShellType:
   def __init__(self, ID=0, PID=0, n0=0, n1=0, n2=0, n3=0):
      self.NumNodes = 4
      self.ID = ID
      self.PID = PID
      self.ElNode = [0]*self.NumNodes
      self.Included = True
      self.ElNode[0] = n0
      self.ElNode[1] = n1
      self.ElNode[2] = n2
      self.ElNode[3] = n3
      
class ThickShellType:
   def __init__(self, ID=0, PID=0, n0=0, n1=0, n2=0, n3=0, n4=0, n5=0, n6=0, n7=0):
      self.NumNodes = 8
      self.ID = ID
      self.PID = PID
      self.ElNode = [0]*self.NumNodes
      self.Included = True
      self.ElNode[0] = n0
      self.ElNode[1] = n1
      self.ElNode[2] = n2
      self.ElNode[3] = n3
      self.ElNode[4] = n4
      self.ElNode[5] = n5
      self.ElNode[6] = n6
      self.ElNode[7] = n7
      
class PartType:
   def __init__(self, Name, PID=0):
      self.Name = Name
      self.PID = PID
      self.Include = False
      self.Thickness = 0.001
      self.ElementType = 0
      self.RigidConstraints = "7, 7"
      self.Mass = 0.0
      self.ForceY = 0.0
      self.nd2D_start=0
      self.nd2D_end=0
      self.NumQuarters = 1
      self.NodeIndex3D_Start=0
      self.NodeIndex3D_End=0
      self.ElemIndex3D_Start=0
      self.ElemIndex3D_End=0
      self.NumOffset = 0
      self.NumNodes = 0
      self.NumElements = 0
      self.MoveY = 0.0
      self.ExtremeY = 0.0
      self.MinXZ = 0.0
      self.MaxXZ = 0.0
      self.ContactPenaltyScale = 0.1
      self.ReverseNormals = False
      self.ElementThickness=False
      self.Geometry = []
      
#Variable definition
Outline2D = []
VarValue = []
input_data={}
Common=CCommon()
Data = CData()
Results=CResults()
PartsNode3D = []
PartsElement3D = []
Part = [] 
ArcLength=[]

def reset_vars():
    global Outline2D
    global VarValue
    global input_data
    global Common
    global Data
    global Results
    global PartsNode3D
    global PartsElement3D
    global Part
    global ArcLength
    global SetBoundary
    global nQuarters
    global NumOffset
    global ToolsDivPerQuarter
    
    # clear vars
    Outline2D = None
    VarValue = None
    input_data = None
    Common = None
    Data = None
    Results = None
    PartsNode3D = None
    PartsElement3D = None
    Part = None
    ArcLength = None
    SetBoundary = None
    nQuarters = None
    NumOffsetv = None
    ToolsDivPerQuarter = None
    
    #initialize vars
    Outline2D = []
    VarValue = []
    input_data={}
    Common=CCommon()
    Data = CData()
    Results=CResults()
    PartsNode3D = []
    PartsElement3D = []
    Part = [] 
    ArcLength=[]
    print('Variables reset.')
    

#Funtion definition - Model Generation 
def Node3D(nd, x, y, z, PID, ElementThickness):
   global SetBoundary
   global nQuarters
   global NumOffset
   PartsNode3D.append(NodeType3D(nd+NumOffset, x, y, z, PID, ElementThickness))
   if SetBoundary:
      if nQuarters == 1:
         if abs(z) < 0.001:
            PartsNode3D[nd].Tc = 3
            PartsNode3D[nd].Rc = 4
            if abs(x) < 0.001:
               PartsNode3D[nd].Tc = 6
               PartsNode3D[nd].Rc = 7
         elif abs(x) < 0.001:
            PartsNode3D[nd].Tc = 1
            PartsNode3D[nd].Rc = 5
      elif nQuarters == 2:
         if abs(z) < 0.001:
            PartsNode3D[nd].Tc = 3
            PartsNode3D[nd].Rc = 4

def Outline_rev():
    for i in range(len(Outline2D)-1, -1, -1):
        Outline2D.append(Outline2D.pop(i))
            
def Point2D(x,y,PID,ElementThickness=0):
    Outline2D.append(ToolsNode2DType(x, y, PID, ElementThickness))

def Arc2D(Ang0, Ang1, Rad, XC, YC, PID, t0=0, t1=0):
   ElSize = Common.ElementSize
   AngDiff = Ang1 - Ang0
   nDiv = abs(int(12 * AngDiff /math.pi))
   if nDiv < 1: nDiv = 1
   ArcLeng = abs(AngDiff * Rad)
   if PID==100: ArcLength.append(ArcLeng)
   ElLeng = ArcLeng / nDiv
   
   if ElLeng > ElSize:
      nDiv = int(ArcLeng / ElSize + 1)
      ElLeng = ArcLeng / nDiv
   dAng = AngDiff / nDiv
   Ang = Ang0
   for i in range(nDiv):
      Ang += dAng
      x = XC + Rad * math.cos(Ang)
      y = YC + Rad * math.sin(Ang)
      if t1 != 0 or t0 != 0:
          if t1 < t0:
              ElementThickness=t0 - ((t0-t1)/nDiv)*(i+1)
          else:
              ElementThickness=t0 + ((t1-t0)/nDiv)*(i+1)
          Point2D(x, y, PID, ElementThickness)
      else:
          Point2D(x, y, PID)

def Line2D(xEnd, yEnd, PID, t0=0, t1=0):
   ElSize = Common.ElementSize
   ndLast = len(Outline2D) - 1
   xStart = Outline2D[ndLast].x
   yStart = Outline2D[ndLast].y
   Lx = xEnd - xStart
   Ly = yEnd - yStart
   LineLeng = math.sqrt(Lx**2 + Ly**2)
   if PID==100: ArcLength.append(LineLeng)
   nDiv = int(LineLeng/ElSize)
   if nDiv == 0: nDiv=1
   dx = Lx / nDiv
   dy = Ly / nDiv
   x = xStart
   y = yStart
   for i in range(nDiv):
      x += dx
      y += dy
      if t1 != 0 or t0 != 0:
          if t1 < t0:
              ElementThickness=t0 - ((t0-t1)/nDiv)*(i+1)
          else:
              ElementThickness=t0 + ((t1-t0)/nDiv)*(i+1)
          Point2D(x, y, PID, ElementThickness)
      else:
          Point2D(x, y, PID)

def center_point(r, alpha_start):
    if not Outline2D:
        xc = round(0-r*math.cos(math.radians(alpha_start)),10)
        yc = round(0-r*math.sin(math.radians(alpha_start)),10)
    else:
        xc = round(Outline2D[-1].x-r*math.cos(math.radians(alpha_start-90)),10)
        yc = round(Outline2D[-1].y-r*math.sin(math.radians(alpha_start-90)),10)
    return xc, yc

def GeneratePartsOutlines():
   global Common
   for i in range(Common.NumParts):
      Common.ElementSize = 1.0 # for tools
      if i == 0:
         Part[i].nd2D_start = 0
      else:
         Part[i].nd2D_start = Part[i-1].nd2D_end
      if(Part[i].Name == "Blank" and Data.CreateBlank):
         Common.ElementSize = Common.BlankElemSize # for blank
         CreateBlank(Part[i])
      elif(Part[i].Name == "Airbag"):
         Common.ElementSize = Common.BlankElemSize
         CreateAirbag(Part[i])
      elif(Part[i].Name == "Ring"):
         CreateRing(Part[i])
      Part[i].nd2D_end = len(Outline2D)

def WriteCommandsBuckle(FileName):
    fout = open(FileName, "w")
    fout.write('$-------------------------------------------------------------------------------\n')
    fout.write('$ This is the main simulation file; run this file with LS-Dyna\n')
    fout.write('$-------------------------------------------------------------------------------\n')
    fout.write('$\n')
    fout.write('$-------------------------------------------------------------------------------\n')
    fout.write('$   Units: Millimeter, Millisec, Kilogram, KiloNewton, Kelvin\n')
    fout.write('$-------------------------------------------------------------------------------\n')
    fout.write('$\n')
    fout.write('*KEYWORD memory=200m\n')
    fout.write('$\n')
    fout.write('*TITLE\n')
    fout.write('Top Hat Channel Bending\n')
    fout.write('$\n')
    fout.write('$-------------------------------------------------------------------------------\n')
    fout.write('$***parameters section***\n')
    fout.write('$--------1---------2---------3---------4---------5---------6---------7---------8\n')
    fout.write('$\n')
    fout.write('$---------------------\n')
    fout.write('$ ENDTIM - termination time\n')
    fout.write('$ GAUGE - material thickness\n')
    fout.write('$ TLGAUGE - virtual tool gauge\n')
    fout.write('$ COF - coefficient of friction\n')
    fout.write('$ DISP - punch displacement\n')
    fout.write('$ TOL - initial gap tolerance\n')
    fout.write('$ DINT - database output interval\n')
    fout.write('$---------------------\n')
    fout.write('$\n')
    fout.write('*PARAMETER\n')
    fout.write('$ simulation parameters\n')
    fout.write('rENDTIM, 1000.0\n')
    fout.write('rCOFS, 0.12\n')
    fout.write('rCOFD, 0.12\n')
    fout.write('rBASEDAMP, 0.05\n')
    fout.write('rSTFDMP, 0.05\n')
    fout.write('rDINT, 0.1\n')
    fout.write('$\n')
    fout.write('$ tooling positioning\n')
    fout.write('rTLMOV_Y, 0\n')
    fout.write('$\n')
    fout.write('$ airbag infow rate\n')
    fout.write('rFLOW, 4.0e-5\n')
    fout.write('rTINIT, 25.0\n')
    fout.write('$\n')
    fout.write('rTOL, 0.01\n')
    fout.write('rGAUGE, 0.208\n')
    fout.write('rTLGAUGE, 0.01\n')
    fout.write('$\n')
    fout.write('$---------------------\n')
    fout.write('$ derived parameters from the initila parameters\n')
    fout.write('$---------------------\n')
    fout.write('$\n')
    fout.write('$-------------------------------------------------------------------------------\n')
    fout.write('$***transforms and includes***\n')
    fout.write('$--------1---------2---------3---------4---------5---------6---------7---------8\n')
    fout.write('$\n')
    fout.write('$---------------------\n')
    fout.write('*INCLUDE\n')
    fout.write('_5182_Standard.material\n')
    fout.write('$\n')
    fout.write('*INCLUDE\n')
    fout.write('%s\n' %(Data.Blank3D_File))
    fout.write('*INCLUDE\n')
    fout.write('%s\n' %(Data.Tools3D_File))
    fout.write('$---------------------\n')
    fout.write('$\n')
    fout.write('$-------------------------------------------------------------------------------\n')
    fout.write('$***control section***\n')
    fout.write('$--------1---------2---------3---------4---------5---------6---------7---------8\n')
    fout.write('$\n')
    fout.write('*CONTROL_TERMINATION\n')
    fout.write('&ENDTIM\n')
    fout.write('$ stop simulation when the central node exceedes the maximum lip height\n')
    fout.write('*TERMINATION_NODE\n')
    fout.write('$#     nid      stop      maxc      minc\n')
    fout.write('         1         2         0 -10000000\n')
    fout.write('$\n')
    fout.write('$---------------------\n')
    fout.write('*CONTROL_TIMESTEP\n')
    fout.write('$#  dtinit    tssfac      isdo    tslimt     dt2ms      lctm     erode     ms1st\n')
    fout.write('     0.000     0.000         0     0.000     0.000         0         0         0\n')
    fout.write('$#  dt2msf   dt2mslc     imscl\n')
    fout.write('     0.000         0         0\n')
    fout.write('$---------------------\n')
    fout.write('*CONTROL_CONTACT\n')
    fout.write('$$  SLSFAC    RWPNAL    ISLCHK    SHLTHK    PENOPT    THKCHG     ORIEN    ENMASS\n')
    fout.write('       0.2       1.0         2                             1         2          \n')
    fout.write('$$  USRSTR    USRFRC     NSBCS    INTERM     XPENE     SSTHK      ECDT   TIEDPRJ\n')
    fout.write('                                                                                \n')
    fout.write('$$   SFRIC     DFRIC       EDC    INTVFC        TH     TH_SF    PEN_SF\n')
    fout.write('                                                                      \n')
    fout.write('$$  IGNORE    FRCENG   SKIPRWG    OUTSEG   SPOTSTP   SPOTDEL   SPOTHIN\n')
    fout.write('                                                                      \n')
    fout.write('$$    ISYM    NSEROD    RWGAPS    RWGDTH     RWKSF      ICOV    SWRADF    ITHOFF\n')
    fout.write('         1                                                                      \n')
    fout.write('$$  SHLEDG    PSTIFF\n')
    fout.write('\n')
    fout.write('$---------------------\n')
    fout.write('*CONTROL_HOURGLASS\n')
    fout.write('$      IHQ        QH\n')
    fout.write('         1       0.1\n')
    fout.write('$\n')
    fout.write('*DAMPING_GLOBAL\n')
    fout.write('20\n')
    fout.write('$ damping curve\n')
    fout.write('*DEFINE_CURVE\n')
    fout.write('20, 0, &ENDTIM, &BASEDAMP\n')
    fout.write('0.0, 1.0\n')
    fout.write('1.0, 1.0\n')
    fout.write('$\n')
    fout.write('*DAMPING_PART_STIFFNESS\n')
    fout.write('100,&STFDMP\n')
    fout.write('$\n')
    fout.write('$-------------------------------------------------------------------------------\n')
    fout.write('$***database and output section***\n')
    fout.write('$--------1---------2---------3---------4---------5---------6---------7---------8\n')
    fout.write('$\n')
    fout.write('*DATABASE_EXTENT_BINARY\n')
    fout.write('$    neiph     neips    maxint    strflg    sigflg    epsflg    rltflg    engflg\n')
    fout.write('         1         0         3         1         1         1         1         1\n')
    fout.write('$   cmpflg    ieverp    beamip     dcomp      shge     stssz\n')
    fout.write('         0         1         0         0         2         2\n')
    fout.write('$\n')
    fout.write('$---------------------\n')
    fout.write('$ various useful databases\n')
    fout.write('$---------------------\n')
    fout.write('*DATABASE_ABSTAT\n')
    fout.write('     &DINT\n')
    fout.write('$\n')
    fout.write('*DATABASE_RCFORC\n')
    fout.write('     &DINT\n')
    fout.write('$\n')
    fout.write('*DATABASE_GLSTAT\n')
    fout.write('     &DINT\n')
    fout.write('$\n')
    fout.write('*DATABASE_MATSUM\n')
    fout.write('     &DINT\n')
    fout.write('$\n')
    fout.write('*DATABASE_RBDOUT\n')
    fout.write('     &DINT\n')
    fout.write('$\n')
    fout.write('$ parts for output to dynain\n')
    fout.write('$---------------------\n')
    fout.write('*SET_PART\n')
    fout.write('100\n')
    fout.write('100\n')
    fout.write('$\n')
    fout.write('$ dynain output\n')
    fout.write('$---------------------\n')
    fout.write('*INTERFACE_SPRINGBACK_LSDYNA\n')
    fout.write('100, , 10\n')
    fout.write('$---------------------\n')
    fout.write('$\n')
    fout.write('$-------------------------------------------------------------------------------\n')
    fout.write('$***constraints and boundary conditions***\n')
    fout.write('$--------1---------2---------3---------4---------5---------6---------7---------8\n')
    fout.write('$\n')
    fout.write('$ airbag\n')
    fout.write('*SET_PART\n')
    fout.write('101\n')
    fout.write('100, 101, 102\n')
    fout.write('*AIRBAG_SIMPLE_AIRBAG_MODEL\n')
    fout.write('$ sid, sidtyp, rbid, vsca, psca, vini, mwd, spsf\n')
    fout.write('101, 1, 0\n')
    fout.write('$ cv, cp, t, lcid, mu, area, pe, r0\n')
    fout.write('718.0, 1005, &TINIT, 1, 0.0, 0.0, 0.0, 1.29e-9\n')
    fout.write('$ lou\n')
    fout.write('0\n')
    fout.write('$\n')
    fout.write('*DEFINE_CURVE\n')
    fout.write('$#    lcid      sidr       sfa       sfo      offa      offo    dattyp     lcint\n')
    fout.write('         1         0   &ENDTIM     &FLOW\n')
    fout.write('$#                a1                  o1 \n')
    fout.write('0.0, 1.5\n')
    fout.write('1.0, 0.5\n')
    fout.write('$\n')
    fout.write('$-------------------------------------------------------------------------------\n')
    fout.write('$***part data definitions***\n')
    fout.write('$--------1---------2---------3---------4---------5---------6---------7---------8\n')
    fout.write('$\n')
    fout.write('*PART\n')
    fout.write('Blank\n')
    fout.write('$#     pid     secid       mid     eosid      hgid      grav    adpopt      tmid\n')
    fout.write('       100       100       100         0         0         0         0         0\n')
    fout.write('$\n')
    fout.write('*SECTION_SHELL\n')
    fout.write('100, 16, 0.8333, 7\n')
    fout.write('&GAUGE\n')
    fout.write('$\n')
    fout.write('$---------------------\n')
    fout.write('*PART\n')
    fout.write('Ring\n')
    fout.write('1, 1, 1\n')
    fout.write('$\n')
    fout.write('*PART_MOVE\n')
    fout.write('1, 0.0, &TLMOV_Y, 0.0\n')
    fout.write('*PART\n')
    fout.write('Airbag\n')
    fout.write('101, 1, 1\n')
    fout.write('$\n')
    fout.write('*PART\n')
    fout.write('Gasket\n')
    fout.write('102, 1, 2\n')
    fout.write('$\n')
    fout.write('*SECTION_SHELL\n')
    fout.write('1, 16, 0.8333, 2\n')
    fout.write('&TLGAUGE\n')
    fout.write('$\n')
    fout.write('*MAT_RIGID\n')
    fout.write('$#     mid        ro         e        pr         n    couple         m     alias\n')
    fout.write('         1 7.8500E-6 210.00000  0.300000     0.000     0.000     0.000          \n')
    fout.write('$#     cmo      con1      con2\n')
    fout.write('  1.000000         7         7\n')
    fout.write('$# lco or a1      a2        a3        v1        v2        v3\n')
    fout.write('\n')
    fout.write('$\n')
    fout.write('*MAT_NULL\n')
    fout.write('$#     mid        ro        pc        mu     terod     cerod        ym        pr\n')
    fout.write('         2 7.8500E-6       0.0       0.0     0.000     0.000   210.000       0.3\n')
    fout.write('$\n')
    fout.write('$-------------------------------------------------------------------------------\n')
    fout.write('$***contact definitions***\n')
    fout.write('$--------1---------2---------3---------4---------5---------6---------7---------8\n')
    fout.write('$\n')
    fout.write('*CONTACT_FORMING_ONE_WAY_SURFACE_TO_SURFACE_ID\n')
    fout.write('$#     cid                                                                 title\n')
    fout.write('         1Die-Blank\n')
    fout.write('$#    ssid      msid     sstyp     mstyp    sboxid    mboxid       spr       mpr\n')
    fout.write('       100         1         3         3         0         0         0         0\n')
    fout.write('$#      fs        fd        dc        vc       vdc    penchk        bt        dt\n')
    fout.write('     &COFS     &COFD     0.000     0.000 20.000000         0     0.000     0.000\n')
    fout.write('$#     sfs       sfm       sst       mst      sfst      sfmt       fsf       vsf\n')
    fout.write('     0.000     0.000     0.000     0.000     0.000     0.000     0.000     0.000\n')
    fout.write('$\n')
    fout.write('$---------------------\n')
    fout.write('$\n')
    fout.write('*END\n')
    
def MatFile(FileName):
    fout = open(FileName, "w")
    fout.write('*MAT_PIECEWISE_LINEAR_PLASTICITY\n')
    fout.write('$ Mass scaling = 10, original density = 2.75E-6\n')
    fout.write('$      mid        ro         e        pr      sigy      etan      fail      tdel\n')
    fout.write('       100   2.75e-5      71.0       0.3\n')
    fout.write('$        c         p      lcss      lscr        vp\n')
    fout.write('                           100          \n')
    fout.write('$     eps1      eps2      eps3      eps4      eps5      eps6      eps7      eps8\n')
    fout.write('\n')
    fout.write('$      es1       es2       es3       es4       es5       es6       es7       es8\n')
    fout.write('\n')
    fout.write('$\n')
    fout.write('*DEFINE_CURVE\n')
    fout.write('$     lcid      sidr       sfa       sfo      offa      offo\n')
    fout.write('       100                 1.0       1.0       0.0       0.0\n')
    fout.write('$ Can End Stock AA5182\n')
    fout.write('$ Stress units: kN/mm2\n')
    fout.write('$ plastic strain, stress\n')
    fout.write('0, 0.32367\n')
    fout.write('0.0002, 0.32824\n')
    fout.write('0.0005, 0.33086\n')
    fout.write('0.0009, 0.33329\n')
    fout.write('0.0014, 0.33564\n')
    fout.write('0.002, 0.33795\n')
    fout.write('0.0029, 0.34083\n')
    fout.write('0.0041, 0.34404\n')
    fout.write('0.0057, 0.34764\n')
    fout.write('0.0078, 0.35167\n')
    fout.write('0.0106, 0.35625\n')
    fout.write('0.0143, 0.36145\n')
    fout.write('0.0193, 0.36749\n')
    fout.write('0.026, 0.37445\n')
    fout.write('0.035, 0.38236\n')
    fout.write('0.047, 0.39186\n')
    fout.write('0.063, 0.40286\n')
    fout.write('0.085, 0.41538\n')
    fout.write('0.114, 0.42818\n')
    fout.write('0.153, 0.44045\n')
    fout.write('0.205, 0.45087\n')
    fout.write('0.275, 0.45855\n')
    fout.write('0.368, 0.46313\n')
    fout.write('0.493, 0.46525\n')
    fout.write('0.661, 0.46594\n')
    fout.write('1, 0.46609\n')
    fout.write('$\n')
    fout.write('*END\n')
    
    
def GetModelData(File):
   global VarValue
   global Part
   global input_data
   # position of last variable = 11
   VarName ='Dimensions','Gauge','BlankElementType','BlankElementSize','BlankThkDivision','NumQuarters', 'RadialMeshDiam', 'y_lip_start', 'shell_diam', 'AirbagVolume', 'Roughness', 'Density'
   nVars = len(VarName)
   values=False
   for i in range(nVars): VarValue.append(0.0)
   fp = open(File)
   for line in fp:
       if line[0] != '#': # comment, skip
          items=line.strip().split(',')
          if items[0] == "Part":
             Name = str(items[1].strip())
             PID = int(items[2])
             Part.append(PartType(Name, PID))
             Common.NumParts += 1
             values = True
          elif values == True:
              temp=[]
              for i in items:
                  try: 
                      temp.append(float(i))
                  except ValueError:
                    temp.append(i) 
              Part[Common.NumParts-1].Geometry.append(temp)
          else:
             ii = -1
             for i in range(nVars):
                if items[0] == VarName[i]:
                   VarValue[i] = float(items[1])
                   ii = i
                   break
             if ii < 0:
                print("Error in file %s, variable name not recognised, line:\n%s"%(File, line.rstrip()))
                
   Data.Dimensions=VarValue[0]
   Data.Gauge=VarValue[1]
   Data.AirbagVolume=VarValue[9]
   Data.shell_diam=VarValue[8]
   Data.y_lip_start=VarValue[7]
   Data.RadialMeshDiam=VarValue[6]
   Results.Roughness=VarValue[10]
   Data.Density=VarValue[11]
   Common.BlankElemSize = VarValue[3]
   Common.ElementSize = Common.BlankElemSize
   NumQuarters = int(VarValue[5])
   Data.NumQuarters = NumQuarters
   for i in range(Common.NumParts):
      Part[i].NumQuarters = NumQuarters
   #Define input data for database
   for i in range(len(VarName)):
       input_data[VarName[i]] = VarValue[i]
   input_data['Type'], input_data['Radius'], input_data['Angle'] = map(list, zip(*Part[0].Geometry))

def OutputPart3D(Part, fout):
   OffsetIDs = Part.NumOffset - 1
   fout.write("$ Part %s, PID = %d\n"%(Part.Name, Part.PID))
   if Part.Name=='Gasket':
       if Part.ElementType == 0:
          fout.write("*ELEMENT_SHELL\n")
       for i in range(Part.ElemIndex3D_Start, Part.ElemIndex3D_End):
          fout.write('%d, %d, %d, %d, %d, %d\n' %(PartsElement3D[i].ID, PartsElement3D[i].PID, PartsElement3D[i].ElNode[0], PartsElement3D[i].ElNode[1], PartsElement3D[i].ElNode[2], PartsElement3D[i].ElNode[3]))
   else:
       fout.write("*NODE\n")
       for i in range(Part.NodeIndex3D_Start, Part.NodeIndex3D_End):
          x = PartsNode3D[i].x
          y = PartsNode3D[i].y
          z = PartsNode3D[i].z
          Tc = PartsNode3D[i].Tc
          Rc = PartsNode3D[i].Rc
          fout.write('%d, %.4f, %.4f, %.4f'%(PartsNode3D[i].ID, x, y, z))
          if Tc == 0:
             fout.write('\n')
          else:
             fout.write(', %d, %d\n'%(Tc, Rc))
       if Part.ElementType == 0 and not Part.ElementThickness:
           fout.write("*ELEMENT_SHELL\n")
       elif Part.ElementType == 0 and Part.ElementThickness:
           fout.write("*ELEMENT_SHELL_THICKNESS\n")
       elif Part.ElementType == 1:
          fout.write("*ELEMENT_TSHELL\n")
       elif Part.ElementType == 2:
          fout.write("*ELEMENT_BEAM\n") 
       for i in range(Part.ElemIndex3D_Start, Part.ElemIndex3D_End):
          fout.write('%d, %d'%(PartsElement3D[i].ID, PartsElement3D[i].PID))
          nNodesFormed = PartsElement3D[i].NumNodes
          for k in range(nNodesFormed):
             ndIndex = PartsElement3D[i].ElNode[k]
             fout.write(', %d'%(PartsNode3D[ndIndex].ID))
          fout.write("\n")
          if Part.ElementThickness:
            for k in range(nNodesFormed):
               ndIndex = PartsElement3D[i].ElNode[k]
               if k==0: 
                   fout.write('%.4f'%(PartsNode3D[ndIndex].ElementThickness))
               else:
                   fout.write(', %.4f'%(PartsNode3D[ndIndex].ElementThickness))
            fout.write("\n")

def GenerateParts3D():
   ToolsDivPerQuarter = 51
   RadialMeshStart = Data.RadialMeshDiam / 2.0
   # 1 - Blank specific (Part 0)
   if Data.CreateBlank and Data.Dimensions > 2:
      Part[0].NumOffset = 1
      Part[0].NodeIndex3D_Start=0
      Part[0].ElemIndex3D_Start=0
      Part[0].NumNodes = 0
      Part[0].NumElements = 0
      CreatePart3D(Part[0], 0, RadialMeshStart, 1)  # Blank
      ToolsDivPerQuarter=int(max([Outline2D[i].DivHoop for i in range(len(Outline2D)) if Outline2D[i].PID==100])/4)
      Common.maxShellDivHoop=int(max([Outline2D[i].DivHoop for i in range(len(Outline2D)) if Outline2D[i].PID==100]))
   if not Data.CreateBlank:
      Part[0].NumNodes = nNodesFormed
   # 2 - Tools
   iPrev = 0
   for i in range(1, Common.NumParts-1):
      if Part[i].Include:
         Part[i].NumOffset = Part[iPrev].NumOffset + int(Part[iPrev].NumNodes/1000+1)*1000 # round up to even 1000
         Part[i].NodeIndex3D_Start = Part[iPrev].NodeIndex3D_End
         Part[i].ElemIndex3D_Start = Part[iPrev].ElemIndex3D_End
         CreatePart3D(Part[i], ToolsDivPerQuarter, RadialMeshStart) # tools
         iPrev = i
        
def CreatePart3D(Part, DivPerQuarter = 0, RadialMeshStart = 1000.0, SetBound = False):
   global SetBoundary
   global nQuarters
   global NumOffset
   global ToolsDivPerQuarter
   NumOffset = Part.NumOffset
   SetBoundary = SetBound
   nQuarters = Part.NumQuarters # copy to global

   # 1 - Nodes
   HoopAngle = math.pi/2 * nQuarters
   Node2D_Start = Part.nd2D_start
   Node2D_End = Part.nd2D_end
   nd = 0
   iStart = Node2D_Start
   iEnd = Node2D_End
   RadXZ = Outline2D[iStart].x
   y2D = Outline2D[iStart].y
   bCentrePoint = False
   if RadXZ < 0.001:
      # centre node
      Node3D(nd, 0.0, y2D, 0.0, Part.PID, ElementThickness=Outline2D[iStart].ElementThickness)
      Outline2D[iStart].DivHoop = 0
      DivHoopPrev = 0
      nd += 1
      iStart += 1
      bCentrePoint = True
      DivPerQuarter = 0  ## force it for parts with a centre point
   for i in range(iStart, iEnd):
      RadXZ_Prev = RadXZ
      y2D_Prev = y2D
      RadXZ = Outline2D[i].x
      y2D = Outline2D[i].y
      PathDist = math.sqrt((RadXZ - RadXZ_Prev)**2 + (y2D - y2D_Prev)**2)
      ElLeng = PathDist
      ArcLeng = RadXZ * HoopAngle
      if DivPerQuarter == 0:
         DivHoop = int((ArcLeng/ElLeng+0.5)/2)*2 # force to even
         if RadXZ >= RadialMeshStart:
             DivHoop = DivHoopPrev
         if i == iStart and bCentrePoint:
            DivHoop = int(nQuarters * 2)
         elif DivHoop < DivHoopPrev:
            DivHoop = DivHoopPrev
         elif DivHoop > DivHoopPrev+4:
             DivHoop = DivHoopPrev+4
             if Part.PID != 100 and DivHoop > Common.maxShellDivHoop:
                 DivHoop=248
         elif DivHoop % 4 != 0:
            DivHoop += 2
      else:
         DivHoop = DivPerQuarter * nQuarters
      DivHoopPrev = DivHoop
      Outline2D[i].DivHoop = DivHoop
      ElementThickness=Outline2D[i].ElementThickness
      AngleStep = HoopAngle / DivHoop
      if nQuarters==4: DivHoop -= 1
      for k in range(DivHoop + 1):
         Angle = AngleStep * k
         x = RadXZ * math.cos(Angle)
         y = y2D
         z = RadXZ * math.sin(Angle)
         Node3D(nd, x, y, z, Part.PID, ElementThickness)
         nd += 1
   #
   Part.NumNodes = nd
   #Part.NodeIndex3D_Start # was set earlier
   Part.NodeIndex3D_End = Part.NodeIndex3D_Start + Part.NumNodes
   if Part.PID == 100 and Part.NumNodes != 0:  # is the Blank, note its edge nodes
      if nQuarters < 4:
         Common.EdgeNd1 = nd -1
         Common.EdgeNd0 = Common.EdgeNd1 - DivHoop
      else:
         Common.EdgeNd1 = nd
         Common.EdgeNd0 = Common.EdgeNd1 - DivHoop - 1
   if Part.ElementType == 1:
      # create bottom node-plane
      yMove = Part.Thickness / 2.0
      for i in range(Part.NodeIndex3D_Start, Part.NodeIndex3D_End):
         PartsNode3D.append(NodeType3D(nd + NumOffset, PartsNode3D[i].x, PartsNode3D[i].y - yMove, PartsNode3D[i].z, Part.PID))
         PartsNode3D[i].y += yMove  # shift top surface to t/2
         PartsNode3D[nd].Tc = PartsNode3D[i].Tc
         PartsNode3D[nd].Rc = PartsNode3D[i].Rc
         nd += 1
      Part.NumNodes = nd
      Part.NodeIndex3D_End = Part.NodeIndex3D_Start + Part.NumNodes
      tOffs = int(Part.NumNodes / 2)
   #
   # 2 - Elements
   PID = Part.PID
   nShell = 0
   n0_start = Part.NodeIndex3D_Start
   n0 = Part.NodeIndex3D_Start
   if bCentrePoint:
      # at centre, quads:
      nQuads = nQuarters
      n1 = n0 + 1
      for iQuad in range(nQuads):
         if iQuad < 3:
            n3 = n1 + 2
         else:
            n3 = n0_start + 1
         n2 = n1 + 1
         if Part.ElementType == 1:
            PartsElement3D.append(ThickShellType(nShell + NumOffset, PID, n0, n1, n2, n3,
                                          n0+tOffs, n1+tOffs, n2+tOffs, n3+tOffs))
         else:
            PartsElement3D.append(ShellType(nShell + NumOffset, PID, n0, n1, n2, n3))
         nShell += 1
         n1 += 2
      DivHoop1 = nQuads * 2
      n0 += 1 
      if nQuads < 4: n1 += 1
      
      
   else:
      DivHoop1 = Outline2D[iStart].DivHoop
      n0 = Part.NodeIndex3D_Start
      if nQuarters < 4:
         n1 = n0 + DivHoop1 + 1
      else:
          n1 = n0 + DivHoop1
   TrPos = [0] * 4
   for i in range(iStart+1, iEnd):
      n0_sav = n0
      n1_sav = n1
      DivHoop0 = DivHoop1
      DivHoop1 = Outline2D[i].DivHoop
      DivDiff = DivHoop1 - DivHoop0
      if DivDiff > 0:
         # TrPos pointer uses 0 as first item
         TrPos[0] = int(DivHoop1/(2*DivDiff))
         TrPos[1] = int(DivHoop1/(DivDiff/2))- (TrPos[0]+1)
         TrPos[2] = 2*DivHoop1 # set to a large value for DivDiff <= 2
         if DivDiff > 2:
            TrPos[2] = DivHoop1 - 1 - TrPos[1]
            TrPos[3] = DivHoop1 - 1 - TrPos[0]
      else:
         TrPos[0] = 2*DivHoop1  # set to a large value for DivDiff = 0
      if i == 0:
         # at y-axis - spec case, already dealt with
         pass
      else:
         iTr=0
         for iOut in range(0,DivHoop1):
            n2 = n1 + 1
            n3 = n0 + 1
            if iTr < 4 and iOut == TrPos[iTr]:
               # triangle:
               n3 -= 1
               iTr += 1
            nn2 = n2
            nn3 = n3
            if nQuarters == 4 and iOut == DivHoop1 - 1:
               nn2 = n1_sav
               nn3 = n0_sav
            if nn3 == n0:
               nn3 = nn2 # correct for the triangle!
            if Part.ElementType == 1:
               PartsElement3D.append(ThickShellType(nShell + NumOffset, PID, n0, n1, nn2, nn3,
                                                  n0+tOffs, n1+tOffs, nn2+tOffs, nn3+tOffs))
            else:
               PartsElement3D.append(ShellType(nShell + NumOffset, PID, n0, n1, nn2, nn3))
            nShell += 1
            n0 = n3
            n1 = n2
         if nQuarters < 4:
            n0 += 1
            n1 += 1
   #
   Part.NumElements = nShell
   Part.ElemIndex3D_End = Part.ElemIndex3D_Start + Part.NumElements
   if Part.ReverseNormals:
      ReverseShellNormals(Part)

def ReverseShellNormals(Part):
   ndTemp = [0]*4
   for i in range(Part.ElemIndex3D_Start, Part.ElemIndex3D_End):
      for k in range(4):
         ndTemp[k] = PartsElement3D[i].ElNode[k]
      PartsElement3D[i].ElNode[0] = ndTemp[1]
      PartsElement3D[i].ElNode[1] = ndTemp[0]
      PartsElement3D[i].ElNode[2] = ndTemp[3]
      PartsElement3D[i].ElNode[3] = ndTemp[2]
      
def GenerateParts():
   if Data.Dimensions == 2:
      GenerateParts2D()
   else:
      GenerateParts3D()

def WriteParts3D(BlankFile, ToolsFile):
   if Data.CreateBlank:
      fout = open(BlankFile, "w")
      OutputPart3D(Part[0], fout)
      fout.write("*END\n")
      fout.close()

   fout = open(ToolsFile, "w")
   for i in range(1, Common.NumParts):
      if Part[i].Include:
         OutputPart3D(Part[i], fout)
   fout.write("*END\n")
   fout.close()

def BlankGeneration(GeometryData, PID):
    old_ang=0
    skip=False
    for i in range(len(GeometryData)):
        if GeometryData[i][0] == 'Point':
            if len(GeometryData[i]) == 3:
                Point2D(GeometryData[i][1], GeometryData[i][2], PID)
            else:
                Point2D(GeometryData[i][1], GeometryData[i][2], PID,  GeometryData[i][3])
                t0=GeometryData[i][3]
        elif GeometryData[i][0] == 'Line':
            curr_ang = old_ang + GeometryData[i][2] 
            if len(GeometryData[i]) == 3:
                Line2D(Outline2D[-1].x+GeometryData[i][1]*round(math.cos(math.radians(curr_ang)),10), Outline2D[-1].y+GeometryData[i][1]*round(math.sin(math.radians(curr_ang)),10), PID)
            else:
                t1=GeometryData[i][3]
                Line2D(Outline2D[-1].x+GeometryData[i][1]*round(math.cos(math.radians(curr_ang)),10), Outline2D[-1].y+GeometryData[i][1]*round(math.sin(math.radians(curr_ang)),10), PID, t0, t1)
                t0=t1
            old_ang=curr_ang
        elif GeometryData[i][0] == 'Arc':
            if GeometryData[i-1][0] == 'Point':
                #if GeometryData[i][1] < 0 : GeometryData[i][3] = GeometryData[i][3] #2 too?
                old_ang=GeometryData[i][2]
                curr_ang = old_ang + GeometryData[i][3]
                xc, yc=center_point(GeometryData[i][1], old_ang + 90)
                if len(GeometryData[i]) == 4:
                    Arc2D(math.radians(old_ang), math.radians(curr_ang), GeometryData[i][1], xc, yc, PID)
                else:
                    t1=GeometryData[i][4]
                    Arc2D(math.radians(old_ang), math.radians(curr_ang), GeometryData[i][1], xc, yc, PID, t0, t1)
                    t0=t1
                old_ang = curr_ang + 90
                
            else:
                if GeometryData[i][1] < 0 : GeometryData[i][2] = -GeometryData[i][2]
                elif GeometryData[i][2] < 0: GeometryData[i][1] = -GeometryData[i][1]
                arc_start=old_ang - 90
                #calculate last angle
                if i==len(GeometryData)-1: 
                    curr_ang = 90
                    if old_ang > 180:
                        GeometryData[i][1] = -abs(GeometryData[i][1])
                    elif old_ang < 180:
                        GeometryData[i][1] = abs(GeometryData[i][1])
                    elif old_ang == 180:
                        skip = True
                else: curr_ang = arc_start + GeometryData[i][2]
                xc, yc=center_point(GeometryData[i][1], old_ang)
                if skip: pass
                elif len(GeometryData[i]) == 3:
                    Arc2D(math.radians(arc_start), math.radians(curr_ang), GeometryData[i][1], xc, yc, PID)
                    #print("Center Point:(%s, %s), start_angle: %s°, end_angle: %s°, Radius: %s" %(xc, yc, arc_start, curr_ang, GeometryData[i][1]))
                else:
                    t1=GeometryData[i][3]
                    Arc2D(math.radians(arc_start), math.radians(curr_ang), GeometryData[i][1], xc, yc, PID, t0, t1)
                    t0=t1
                old_ang = curr_ang + 90
                #if last item draw line to zero
                if i==len(GeometryData)-1:
                    Line2D(0, Outline2D[-1].y, PID)
                    #avoid rounding error
                    Outline2D[-1].x = 0

def shell_sanity_check(PID):
    #find intersection
    def ccw(A,B,C):
        return (C.y-A.y)*(B.x-A.x) > (B.y-A.y)*(C.x-A.x)
    def intersect(A,B,C,D):
        return ccw(A,C,D) != ccw(B,C,D) and ccw(A,B,C) != ccw(A,B,D)
    blank_nodes=[[Outline2D[i], Outline2D[i+1]] for i in range(len(Outline2D)-1) if Outline2D[i].PID == PID]
    #find first node which is bigger than RadialMeshStart
    idxRadialMesh=next(i for i, v in enumerate([Outline2D[k].x for k in range(len(Outline2D)) if Outline2D[k].PID == PID]) if v > Data.RadialMeshDiam/2)
    #check if arc length greater ElementSize
    if min(ArcLength) < Common.BlankElementSize:
        Results.Fail=1
    #check if node 1 is below lip (termination criteria)
    elif blank_nodes[0][0].y > Data.y_lip_start:
        Results.Fail = 1
    #check if no radius is in panel
    elif any([i != blank_nodes[0][0].y for i in [Outline2D[k].y for k in range(len(Outline2D)) if Outline2D[k].PID == PID][:idxRadialMesh]]):
        Results.Fail=1
    #check if any x value is below RadialMeshDiam/2
    elif any([i < Data.RadialMeshDiam/2 for i in [Outline2D[k].x for k in range(len(Outline2D)) if Outline2D[k].PID == PID][idxRadialMesh:]]):
        Results.Fail = 1
    #check if airbag is large enough 
    elif [Outline2D[i].y for i in range(len(Outline2D)) if Outline2D[i].PID == PID][-1] - min([Outline2D[i].y for i in range(len(Outline2D)) if Outline2D[i].PID == PID]) < Data.Airbag_height:
        Results.Fail=1
    #check if shell ends between 0 and given diameter
    elif round(max([Outline2D[i].x for i in range(len(Outline2D)) if Outline2D[i].PID == PID]),5) > Data.shell_diam/2 or min([Outline2D[i].x for i in range(len(Outline2D)) if Outline2D[i].PID == PID]) < 0:
        Results.Fail=1
    #check for maximum shell height of 20mm
    elif max([Outline2D[i].y for i in range(len(Outline2D)) if Outline2D[i].PID == PID]) - min([Outline2D[i].y for i in range(len(Outline2D)) if Outline2D[i].PID == PID]) > 20:
        Results.Fail=1
    #check if shell exceeds lip height
    elif max([Outline2D[i].y for i in range(len(Outline2D)) if Outline2D[i].PID == PID]) >= Data.y_lip_start + 0.01:
        Results.Fail=1
    else:
        #check Ring and blank intersections
        ring_nodes=[[ToolsNode2DType(26.6, Data.y_lip_start + Data.Gauge/2 + 0.01/2, 1, 0), ToolsNode2DType(30, Data.y_lip_start + Data.Gauge/2 + 0.01/2, 1, 0)]]
        combined_nodes=blank_nodes + ring_nodes
        combination_list=[[combined_nodes[i], combined_nodes[j]] for i in range(len(combined_nodes)) for j in range(i+2, len(combined_nodes),1)]
        intersections=[intersect(combination_list[i][0][0], combination_list[i][0][1], combination_list[i][1][0], combination_list[i][1][1]) for i in range(len(combination_list))]
        #if any intersections in profile, computational time intensive if other failure modes not checked before
        if any(intersections):
            Results.Fail = 1
        else:
            Results.Fail=0
            
def VolumeCalc(x0, y0, x1, y1):
     def TruncatedConeVolume(h, r, R):
         return (1/3)*np.pi*h*(r**2+r*R+R**2)
 
     def CylinderVolume(R, r, h):
         return np.pi*(R**2-r**2)*h
     V=0
     #if x0 > x1:
         #print(x0, x1)
     if y0 == y1:
         V=CylinderVolume(x1, x0, y1)
     elif y0 != y1  and x1 > x0:
         if y0 > y1:
             #define Cylinder under cone area
             V1 = CylinderVolume(x1, x0, y0)
             #define truncate cone volume
             V2 = TruncatedConeVolume(y0-y1, x0, x1)
             #print(V2)
             #define cylinder volume inside of truncated cone Volume
             V3 = CylinderVolume(x0, 0, y0-y1)
             #Calculate complete Volume
             V=V1+V2-V3
         else:
             #define Cylinder under cone area
             V1 = CylinderVolume(x1, x0, y1)
             #define truncate cone volume
             V2 = TruncatedConeVolume(y1-y0, x1, x0)
             #define cylinder volume of cone height
             V3 = CylinderVolume(x1, 0, y1-y0)
             #Calculate complete Volume
             V=V1+V3-V2
     elif y0 != y1 and x1 < x0: 
         if y1 > y0:
             #define Cylinder under cone area
             V1 = CylinderVolume(x0, x1, y0)
             #define truncate cone volume
             V2 = TruncatedConeVolume(y1-y0, x1, x0)
             #print(V2)
             #define cylinder volume inside of truncated cone Volume
             V3 = CylinderVolume(x1, 0, y1-y0)
             #Calculate complete Volume
             V=-(V1+V2-V3)
         else:
             #define Cylinder under cone area
             V1 = CylinderVolume(x0, x1, y1)
             #define truncate cone volume
             V2 = TruncatedConeVolume(y0-y1, x0, x1)
             #define cylinder volume of cone height
             V3 = CylinderVolume(x1, 0, y0-y1)
             #Calculate complete Volume
             V=-(V1+V3-V2)
     return V
     
def Airbag_height(V, PID):
     x=[Outline2D[i].x for i in range(len(Outline2D)) if Outline2D[i].PID==PID]
     y_min=min([Outline2D[i].y  for i in range(len(Outline2D)) if Outline2D[i].PID==PID])
     y=[Outline2D[i].y - y_min  for i in range(len(Outline2D)) if Outline2D[i].PID==PID]
     Volume=[]
     for i in range(len(x)-1):
         Volume.append(VolumeCalc(x[i], y[i], x[i+1], y[i+1]))
     Volume_shell=sum(Volume)
     
     AirbagVolume=V-Volume_shell
     height=AirbagVolume/(np.pi*x[-1]**2) + y[-1]
     return height        
 
    
def CreateBlank(Part):
    Part.Include = True
    PID = Part.PID
    if len(Part.Geometry[0]) > 3: Part.ElementThickness=True
    relative_start_angle=Part.Geometry[0][2]
    lip_geometry=[['Point', Data.shell_diam/2, 0.0],['Arc', 0.72644, 0, 26.0], ['Arc', 1.3081, 45.0],['Arc', 3.0535, 25.0],['Arc', 1.62, relative_start_angle]]
    Part.Geometry = lip_geometry + Part.Geometry[1:]
    BlankGeneration(Part.Geometry, PID)
    Outline_rev()
    shell_sanity_check(PID)
    Data.Airbag_height = Airbag_height(Data.AirbagVolume, PID)
    
def CreateGasket():
    #KEEP GASKET PART LAST IN FORMING FILE, CURRENT INDEX FUNCTION IN PROGRESS
    #Get Part info for Shell, gasket and airbag
    for i in range(Common.NumParts):
       if(Part[i].Name == "Blank" and Data.CreateBlank):
          BlankPart = Part[i]
       elif(Part[i].Name == "Gasket"):
          GasketPart= Part[i]
          if i == Common.NumParts - 1:
              index=-2
          else: index = - 1
       elif(Part[i].Name == "Airbag"):
          AirbagPart = Part[i]
    GasketPart.Include = True
    PID = GasketPart.PID
    #Write out edge nodes of shell and gasket
    BlankNodes=[PartsNode3D[i] for i in range(len(PartsNode3D)) if PartsNode3D[i].PID==BlankPart.PID and Common.EdgeNd0 < PartsNode3D[i].ID <= Common.EdgeNd1]
    #AirbagNodes=[PartsNode3D[i] for i in range(len(PartsNode3D)) if PartsNode3D[i].PID==AirbagPart.PID and AirbagPart.NumOffset <= PartsNode3D[i].ID < AirbagPart.NumOffset + Common.EdgeNd1 - Common.EdgeNd0]
    AirbagNodes=[PartsNode3D[i] for i in range(len(PartsNode3D)) if PartsNode3D[i].PID==AirbagPart.PID and AirbagPart.NodeIndex3D_End - (Common.EdgeNd1 - Common.EdgeNd0) <= i < AirbagPart.NodeIndex3D_End]
    #define offset for Gasket
    GasketPart.NumOffset = Part[index].NumOffset + int(Part[index].NumNodes/1000+1)*1000
    
    nShell=0
    GasketPart.NodeIndex3D_Start = Part[index].NodeIndex3D_End
    GasketPart.ElemIndex3D_Start = Part[index].ElemIndex3D_End
    GasketPart.ElemIndex3D_Start = len(PartsElement3D)
    
    for i in range(0,len(BlankNodes)-1):
        n0=BlankNodes[i].ID
        n1=AirbagNodes[i].ID
        n3=BlankNodes[i+1].ID
        n2=AirbagNodes[i+1].ID
        PartsElement3D.append(ShellType(nShell + GasketPart.NumOffset, PID, n0, n1, n2, n3))
        nShell+=1 
    PartsElement3D.append(ShellType(nShell + GasketPart.NumOffset, PID, BlankNodes[0].ID, AirbagNodes[0].ID, AirbagNodes[-1].ID, BlankNodes[-1].ID))
    nShell+=1
    GasketPart.ElemIndex3D_End= GasketPart.ElemIndex3D_Start + nShell
    
def CreateAirbag(Part):
   Part.Include = True
   PID = Part.PID
   nBlank=[Outline2D[i] for i in range(len(Outline2D)) if Outline2D[i].PID==100]
   Point2D(0,nBlank[-1].y-Data.Airbag_height, PID)
   Line2D(nBlank[-1].x, nBlank[-1].y-Data.Airbag_height, PID)
   Line2D(nBlank[-1].x, nBlank[-1].y-2, PID)
   
def CreateRing(Part):
    Part.Include=True
    PID = Part.PID
    Point2D(26.6, Data.y_lip_start + Data.Gauge/2 + 0.01/2, PID)
    Line2D(30, Data.y_lip_start + Data.Gauge/2 + 0.01/2, PID)

#def translate highest point to zero
def base_translation(PartsNode3D):
    for i in range(len(PartsNode3D)):
        PartsNode3D[i].y = PartsNode3D[i].y - Data.y_lip_start

def roughness(value):
    for i in range(len(PartsNode3D)):
        if PartsNode3D[i].PID==100:
            PartsNode3D[i].y=random.uniform(PartsNode3D[i].y - value/2, PartsNode3D[i].y + value/2)

def GetPerformanceResults():
    def truncated_cone_slant_area(h, R, r):
        return np.pi*(R+r) * np.sqrt(h**2+(R-r)**2)
    def hollow_zylinder_area(R, r):
        return np.pi*(R**2-r**2)

    x=[Outline2D[i].x for i in range(len(Outline2D)) if Outline2D[i].PID==100]
    y=[Outline2D[i].y for i in range(len(Outline2D)) if Outline2D[i].PID==100]
    
    Area=[]
    for i in range(len(x)-1):
        if y[i] == y[i+1]:
            Area.append(hollow_zylinder_area(x[i+1], x[i]))
        else:
            Area.append(truncated_cone_slant_area(abs(y[i]-y[i+1]),x[i],x[i+1]))
    
    Results.PanelDiam = round(x[np.where(np.array(y)[:-1] != np.array(y)[1:])[0][0]],4)
    Results.UnitHeight = round(max(y) - min(y), 4)
    Results.PanelHeight= round(Data.y_lip_start - y[0], 4)
    Results.CsHeight = round(y[0] - min(y), 4)
    index_min = min(range(len(y)), key=y.__getitem__)
    Results.CsPostion = round(x[index_min], 4)
    Results.ArcLength=round(sum(ArcLength),4)
    Results.SurfaceArea=round(sum(Area),4)
    Results.Mass = round(sum(Area)*Data.Gauge*Data.Density,4)
    Results.Volume=Data.AirbagVolume
    Results.MinRadius=min([abs(Part[0].Geometry[i][1]) for i in range(6, len(Part[0].Geometry)) if Part[0].Geometry[i][0] == 'Arc'])
    
def WritePerformanceResults(File):
    #Result ouput
    with open(File, 'w') as fout:
        sorted_dict = dict(sorted(Results.__dict__.items()))
        for key, value in sorted_dict.items():
              fout.write("%s, %s\n" % (key, value))
              
#plot shell profile
def PlotProfile(File):
    plt.ioff()
    plot_x, plot_y= [], []
    for element in Outline2D:
        if element.PID == 100:
            plot_x.append(element.x)
            plot_y.append(element.y) 
    plt.figure(figsize=(20,10))
    plt.plot(plot_x,plot_y, linewidth=1.0)
    ax = plt.gca()
    ax.set_aspect('equal', adjustable='box')
    plt.xlabel('x-coordinate [mm]')
    plt.ylabel('y-coordinate [mm]')
    plt.savefig(File, bbox_inches='tight', dpi=300)

#get Results
def GetBucklePressure(abstat_file, File):
    with open(abstat_file, 'r') as file:
        data=file.readlines()
    #read in file, split list by empty space
    split_data=[line.strip().split(' ') for line in data] 
    #give data to dataframe
    df=pd.DataFrame(split_data)
    #drop all empty spaces
    df=df.mask(df == '')
    #keep only numeric values and reindex
    df=df[pd.to_numeric(df[0], errors='coerce').notnull()].dropna(axis=1).reset_index(drop=True)
    #reset column index
    df=df = df.T.reset_index(drop=True).T
    #convert numbers to float
    df=df.astype(float)
    #get max pressure
    max_index=df[3].idxmax()
    buckle=(df.iloc[max_index, 0], df.iloc[max_index, 3])
    Results.buckle_time=buckle[0]
    Results.buckle_pressure = buckle[1]*10000*14.5038

    with open(File, 'r+') as fout:
        if not 'buckle_time' in fout.read():
            fout.write('buckle_time, %.4f\n' %(buckle[0]))
            fout.write('buckle_pressure, %.4f\n' %(buckle[1]*10000*14.5038))
    
def appendDatabase(database_path):
    database_dict={**input_data, **dict((name, getattr(Results, name)) for name in dir(Results) if not name.startswith('__'))}
    dict_keys=['Dimensions','Gauge','BlankElementType','BlankElementSize','BlankThkDivision','NumQuarters','RadialMeshDiam','y_lip_start','shell_diam','AirbagVolume','Roughness','Density','Type','Radius','Angle','ArcLength','Fail','Mass','MinRadius','SurfaceArea','Volume','buckle_pressure','buckle_time']
    #check if all keys in dict
    if len(database_dict) == len(dict_keys) and all(key in database_dict for key in dict_keys):
        if os.path.isfile(database_path) == False:
            with open(database_path, 'w', newline='') as database:
                w = DictWriter(database, database_dict.keys())
                w.writeheader()
                w.writerow(database_dict)
        else:
            with open(database_path, 'a', newline='') as database:
                w =DictWriter(database, database_dict.keys())
                w.writerow(database_dict)
            
def FormingData(File):
    LowerAngle=-180
    UpperAngle=180
    LowerRadius=0.2
    UpperRadius=2
    with open(File, 'w') as fout:
        fout.write('#---------------------------------------\n')
        fout.write('# BO parameters\n')
        fout.write('Gauge, 0.208\n')
        fout.write('#---------------------------------------\n')
        fout.write('# fixed parameters\n')
        fout.write('Dimensions, 3\n')
        fout.write('NumQuarters, 4\n')
        fout.write('RadialMeshDiam, 25\n')
        fout.write('AirbagVolume, 36000\n')
        fout.write('Roughness, 0.00035\n')
        fout.write('Density, 0.00271\n')
        fout.write('#\n')
        fout.write('BlankElementType, 0\n')
        fout.write('BlankElementSize, 0.2\n')
        fout.write('BlankThkDivision, 1\n')
        fout.write('y_lip_start, 1.1476\n')
        fout.write('shell_diam, 59.31\n')
        fout.write('Part, Blank, 100\n')
        fout.write('#insert radius and relative angle values\n')
        fout.write('%s, %.1f, %.4f\n' %('Arc', 1337, random.uniform(LowerAngle, UpperAngle)))
        NoParameters=random.randint(8, 20)
        for i in range(0, NoParameters,1):
            fout.write('%s, %.4f, %.4f\n' %('Arc', random.uniform(LowerRadius, UpperRadius), random.uniform(LowerAngle, UpperAngle)))
        fout.write('%s, %.4f, %.1f\n' %('Arc', random.uniform(LowerRadius, UpperRadius), 1337))
        fout.write('Part, Ring, 1\n')
        fout.write('Part, Airbag, 101\n')
        fout.write('#Always keep gasket last part\n')
        fout.write('Part, Gasket, 102\n')