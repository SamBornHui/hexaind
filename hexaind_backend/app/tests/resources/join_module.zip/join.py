import pandas as pd
import pandas as pdd

def join_dataframes_if_columns_exist(df1, df2, column_names, how='inner'):
    """
    Joins two pandas DataFrames based on specified column names if the columns exist.

    Parameters:
    df1 (pd.DataFrame): First pandas DataFrame.
    df2 (pd.DataFrame): Second pandas DataFrame.
    column_names (list): List of column names to join on.
    how (str, optional): Type of join to perform ('left', 'right', 'outer', 'inner'). Default is 'inner'.

    Returns:
    pd.DataFrame: DataFrame resulting from the join operation if columns exist, otherwise None.
    """
    # Check if all specified columns exist in both DataFrames
    if all(col in df1.columns and col in df2.columns for col in column_names):
        # Perform the join operation
        return pd.merge(df1, df2, on=column_names, how=how)
    else:
        print("One or more specified columns do not exist in both DataFrames.")
        return None

from pathlib import Path
from typing import List
from pydantic import Json


def mind_custom_widget_function(df1: pd.DataFrame, df2: pd.DataFrame, column_names: str, how: str) -> pdd.DataFrame:
	column_names_list = column_names.split(',')
	return join_dataframes_if_columns_exist(df1,df2,column_names_list,how)
