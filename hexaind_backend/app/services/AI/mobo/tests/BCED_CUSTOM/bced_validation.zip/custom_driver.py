import pandas as pd
from pathlib import Path
from typing import Any, Dict
import inspect
import ReverseModelGeneratorFunction_v10_clear_vars as model_gen_module


num_r_t_pairs= 11
r_name_list = ['r_1', 'r_2', 'r_3', 'r_4', 'r_5', 'r_6', 'r_7', 'r_8', 'r_9', 'r_10']
t_name_list = ['t_0', 't_1', 't_2', 't_3', 't_4', 't_5', 't_6', 't_7', 't_8', 't_9']
forming_file = "FormingData.txt"
performance_file_col = ['metric', 'value']


def ignore_extra_kwargs(func):
    """Decorator to ignore extra arguments from a dictionary of arguments while function calling."""

    def wrapper(**kwargs):
        """Wrapper function to ignore extra arguments from a dictionary of arguments."""

        # Get the expected keyword arguments for the function.
        expected_kwargs = set(inspect.getfullargspec(func).args)

        # Ignore any extra keyword arguments.
        kwargs = {k: v for k, v in kwargs.items() if k in expected_kwargs}

        # Call the function with the remaining keyword arguments.
        return func(**kwargs)

    return wrapper

def intializePaths(Data, trial_path) -> None:
    Data.trial_path = trial_path
    Data.Tools3D_File = "_Tools.k"
    Data.RunFile = "_ShellBuckle_V2.3.1.k"
    Data.MatFile = "_5182_Standard.material"
    Data.CreateBlank = True

def createFormingDataFile(forming_file: Path, parameters_file: Path) -> None:
    dff = pd.read_csv(parameters_file)
    suggestion = dff.to_dict('records')[0]
    #create FormingData.txt in trial folder using MOBO recommendation
    with open(forming_file, "w") as file:
        file.write("Dimensions, 3 \n")
        file.write("Gauge, 0.208 \n")
        file.write("BlankElementType, 0 \n")
        file.write("BlankElementSize, 0.2 \n")
        file.write("BlankThkDivision, 1 \n")
        file.write("NumQuarters, 4 \n")
        file.write("RadialMeshDiam, 25 \n")
        file.write("y_lip_start, 4.166 \n")
        file.write("shell_diam, 59.31 \n")
        file.write("AirbagVolume, 36000 \n")
        file.write("Roughness, 0.00035 \n")
        file.write("Density, 0.00271 \n")
        file.write("Part, Blank, 100 \n")
        r_t_pairs = []
        for j in range(num_r_t_pairs) :
            if j==0 :
                r_t_pairs = r_t_pairs + [[1337.0,suggestion.get(t_name_list[j])]]
            elif j==num_r_t_pairs-1 : 
                r_t_pairs = r_t_pairs + [[suggestion.get(r_name_list[j-1]),1337.0]]
            else : 
                r_t_pairs = r_t_pairs + [[suggestion.get(r_name_list[j-1]),suggestion.get(t_name_list[j])]]
        for r_t_pair in r_t_pairs :
            file.write('Arc, ' + str(r_t_pair[0]) + ', ' + str(r_t_pair[1]) + '\n')            
        file.write("Part, Ring, 1 \n")
        file.write("Part, Airbag, 101 \n")
        file.write("Part, Gasket, 102")



def PreProcess(parameters_file: Path) -> Any:
    
        trial_index_dir = parameters_file.parent 
        forming_file = trial_index_dir / 'FormingData.txt'
        print('before createFormingDataFile')
        createFormingDataFile(forming_file, parameters_file)
        Data = model_gen_module.Data
        print('before intializePaths')
        intializePaths(Data, trial_index_dir)
        blank_path = trial_index_dir / Data.Blank3D_File
        tools_path = trial_index_dir / Data.Tools3D_File
        plot_path = trial_index_dir / 'Profile.png'
        forming_path = trial_index_dir / Data.FormingDataFile
        shell_path = trial_index_dir / Data.RunFile
        material_path = trial_index_dir / Data.MatFile
        performance_path = trial_index_dir / Data.PerformanceDataFile
        print('after intializePaths')
        #Function calls - model generation - #Contained in "ModelGeneratorFunction_v01.py"
        model_gen_module.GetModelData(forming_path)
        model_gen_module.GeneratePartsOutlines()
        # model_gen_module.PlotProfile(plot_path)
        model_gen_module.GetPerformanceResults()
        model_gen_module.WritePerformanceResults(performance_path)
        
        #check fail criteria
        df2 = pd.read_csv(performance_path, sep=",", header=None)
        df2.columns = performance_file_col
        fail_criter = int(df2[df2['metric']=='Fail'].iloc[0]['value'])
        if fail_criter == 0:
            model_gen_module.GenerateParts()
            model_gen_module.CreateGasket()
            model_gen_module.base_translation(model_gen_module.PartsNode3D)
            model_gen_module.roughness(model_gen_module.Results.Roughness)
            model_gen_module.WriteParts3D(BlankFile = blank_path, ToolsFile=tools_path)
            model_gen_module.MatFile(material_path)
            model_gen_module.WriteCommandsBuckle(shell_path)
        #remove global variable data
        model_gen_module.reset_vars() 
        additional_files = [blank_path, tools_path, shell_path, material_path]

        return fail_criter, additional_files
